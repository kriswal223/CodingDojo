// gives you the number of likes
var likeCount = 0;
// increasin likes by x amount
function increaseLikes() {
    // value of likeCount is set to var + 1 
    likeCount = likeCount + 1;
}
