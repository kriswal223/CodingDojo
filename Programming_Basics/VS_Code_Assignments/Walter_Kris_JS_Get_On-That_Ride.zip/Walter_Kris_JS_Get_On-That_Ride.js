var minHeight = 42;
// variables for riders height greater >= var in order to ride rollercoaster
if (minHeight>=42){
    console.log ('Get on that ride, kiddo!');
}
else {
    console.log ('Sorry kiddo. Maybe next year.');
}


    


