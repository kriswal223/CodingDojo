var minHeight = 42;
// variable for rider min height must be greater than or equal to var in order to ride.
var minAge = 10;
// varible for rider min age must be greater than or equal to var in order to ride.
if (minHeight >= 42 || minAge >= 10){
    console.log('Get on that ride, kiddo!');
}
else {
    console.log('Sorry kiddo. Maybe next year.');
}


    


