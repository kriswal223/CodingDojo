var minHeight = 42;
// variables for riders minimum height to ride rollercoaster
var minAge = 10;
// variables for riders minimum age to ride rollercoaster